# Lean PRD for new mindguard concept

<aside>
<img src="https://www.notion.so/icons/subtask_orange.svg" alt="https://www.notion.so/icons/subtask_orange.svg" width="40px" /> https://lucid.app/lucidchart/5cf3746f-4e8e-4585-912a-b0a93edfb461/edit?view_items=bhNgqBcX9meU&invitationId=inv_3d52dcb3-87d2-467a-a4b7-f6cef6cf3407

</aside>

## Features

- **F1: User Authentication & On-boarding**
    - **User Story:** As a consultant, I want to securely sign up and log in to the Mind Guard platform, so I can access my client workspaces and utilize the insight generation tools.
    - **Functional Requirements:**
        - [x]  F1.1: The system enables a consultant to sign up for a new account.
        - [x]  F1.2: The system enables a consultant to log in using their credentials.
- **F2: Client Workspace Management**
    - **User Story:** As a consultant, I want to create and manage distinct workspaces for each of my clients, so I can organize their specific data sources,  notes, and generated insights in an isolated and secure manner.
    - **Functional Requirements:**
        - [ ]  F2.1: The system enables a consultant to create a new client workspace.
            - [x]  F2.1.1: Creating a workspace requires assigning a client name.
        - [ ]  F2.2: The system enables a consultant to edit the details of an existing client workspace (e.g., client name, goals, description).
        - [ ]  F2.3: The system displays a list of all client workspaces associated with the consultant's account.
        - [ ]  F2.4: Within each client workspace, the system allows the consultant to view a list of connected data tools (integrations) and their current synchronization status.
        - [ ]  F2.5: Within each client workspace, the system provides a manual note field for the consultant to add and edit client-specific context or qualitative information.
        - [ ]  F2.6: The system ensures strict data isolation for each client workspace. Data from one client workspace must not be accessible or blended with another.
- **F3: Tool Integration Management (via Fivetran)**
    - **User Story:** As a consultant, I want to easily and securely connect my clients' various data tools to their respective workspaces using a standardized method like Fivetran, so I can automatically pull relevant data for analysis without manual data entry.
    - **Functional Requirements:**
        - [x]  F3.1: The system integrates with Fivetran to facilitate data tool connections.
        - [x]  F3.2: The system enables a consultant to initiate and manage connections to client data tools through an OAuth2 flow, leveraging Fivetran's capabilities (supporting potentially 700+ tools).
            - [x]  F3.2.1: The system does not store client tool credentials directly; authentication relies on OAuth2 tokens managed via Fivetran.`Fivetran`
        - [x]  F3.3: Data pulled from connected tools is directed into the client-specific, isolated schema in the database.
        - [x]  F3.4: The system allows data synchronization to run on a predefined schedule (e.g., daily). @Nancy Piterskaia
        - [x]  F3.5: The system allows a consultant to trigger on-demand data synchronization for a connected tool within a client workspace. @Nancy Piterskaia `Fivetran`
        - [x]  F3.6: The system displays the status of data synchronizations (e.g., last sync time, success, failure). @Nancy Piterskaia `Fivetran`
- **F4: Data Preparation & Redaction Control**
    - **User Story:** As a consultant, before generating insights, I want to review the data fields pulled from client tools and have the ability to manually exclude specific sensitive or irrelevant fields from being sent to the AI, so I can maintain client confidentiality and improve the relevance of AI prompts.
    - **Functional Requirements:**
        - [x]  F4.1: The system provides an interface for the consultant to view or list data fields available from connected sources within a client's workspace. @Nancy Piterskaia `Fivetran`
        - [x]  F4.2: The system enables the consultant to manually select (include) or deselect (exclude/redact) specific data fields or categories of data prior to their inclusion in the database. @Nancy Piterskaia `Fivetran`
        - [ ]  F4.3: The system uses these consultant-defined redactions/exclusions to filter the data that is compiled for AI prompt injection. @Nancy Piterskaia `Optional`
- **F5: AI-Powered Prompting & Interaction**
    - **User Story:** As a consultant, I want to leverage AI to analyze client data by selecting predefined prompt structures or crafting custom questions, with the system helping to inject relevant data, so I can efficiently generate initial drafts of insights.
    - **Functional Requirements:**
        - [ ]  F5.1: The system provides an interface for the consultant to interact with the AI.
            - [ ]  F5.1.1: The system allows the consultant to choose from a list of predefined prompt types tailored for common consulting analyses. @Nancy Piterskaia
            - [ ]  F5.1.2: The system allows the consultant to write and submit their own custom prompts.`Optional`
        - [ ]  F5.2: The consultant can review and potentially adjust the data context being prepared for the prompt.
        - [ ]  F5.3: The system constructs the final prompt, combining the consultant's chosen written prompt with the prepared data context.
        - [ ]  F5.4: The consultant can review and edit the fully constructed prompt before it is sent to the Large Language Model (LLM).
        - [ ]  F5.5: The system sends the final prompt to the integrated LLM (e.g., OpenAI API) for processing.
        - [ ]  F5.6: (Security) The system interacts with LLMs in a stateless, prompt-only mode. Client data sent in prompts must not be used for training the LLM models. @Craig Taylor
        - [ ]  F5.7: (Security) The AI provider (e.g., OpenAI) must not store logs of the insights or the client data contained within the prompts. @Craig Taylor
- **F6: Insight Generation, Review & Export**
    - **User Story:** As a consultant, I want to receive clear, actionable insights generated by the AI, be able to refine these insights with my expertise, and then export them in standard formats to easily share with my clients.
    - **Functional Requirements:**
        - [ ]  F6.1: The system receives the generated text-based insight from the LLM.
            - [ ]  F6.1.1: The AI-generated insight ideally includes a summary and actionable points, as per the prompt's intention.
        - [ ]  F6.2: The system displays the generated insight clearly to the consultant within the client's workspace.
        - [ ]  F6.3: The system provides an editing capability, allowing the consultant to modify the text of the AI-generated insight.
        - [ ]  F6.4: The system stores the (potentially consultant-edited) insight, associating it with the relevant client workspace and the prompt/data context used.
        - [ ]  F6.5: The system enables the consultant to export the final insight.
            - [ ]  F6.5.1: Export to PDF format is supported.
            - [ ]  F6.5.2: Export to Notion (or a compatible format for Notion import) is supported.
- **F7: Overarching Security & Privacy Mandates**
    - **User Story:** As a consultant entrusting sensitive client data to Mind Guard, I need absolute assurance that the platform adheres to the highest security and privacy standards in its architecture and data handling processes, ensuring confidentiality and integrity at all times.
    - **Functional Requirements:**
        - [ ]  F7.1: **Data Isolation:** Client data must be strictly segregated. This is operationally achieved through mechanisms like per-client database schemas (e.g., in PostgreSQL), ensuring no data blending or cross-client visibility. (Reiterates F2.6 for emphasis).
        - [ ]  F7.2: **AI Interaction Protocol:**
            - [ ]  F7.2.1: LLMs are to be used in a stateless, prompt-only mode.
            - [ ]  F7.2.2: No client data submitted via prompts may be used for training or fine-tuning any AI models by the platform or any third-party AI provider.
            - [ ]  F7.2.3: Logs of AI-generated insights or the specific client data within prompts must not be stored by the AI provider. Platform-side storage of insights (F6.4) is for consultant use only and managed within their secure workspace.
        - [ ]  F7.3: **Authentication Integrity:**
            - [ ]  F7.3.1: Only OAuth2 is to be used for consultant platform authentication.
            - [ ]  F7.3.2: Only OAuth2 (facilitated via Fivetran) is to be used for connecting to client data tools. The Mind Guard platform must not store any direct client tool credentials (e.g., usernames, passwords, API keys that are not OAuth tokens).
        - [ ]  F7.4: **Redaction Capability:** The system must provide a mechanism for consultants to manually exclude specific data fields from being sent to the AI, as detailed in F4.